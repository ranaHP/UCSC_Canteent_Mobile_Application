package com.example.ucsc_canteen_19001355

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
